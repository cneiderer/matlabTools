function [] = GUI_20()
% Demonstrate finding which figure was current before callback execution.  
% Usage:
%
%     Call GUI_20, then create several plots, for example:
%
%     GUI_20
%     x = 0:.1:10;
%     figure;plot(x,x);figure;plot(x,x.^2);figure;plot(x,x.^3)
%
%     Now click on whichever of the figures needs a title.
%     Enter the title in the GUI_20 editbox, then push the button.
%     Clicking on a different figure will make it receive the next title.
%     GUI_20 can also be called AFTER the figures have been created.
%
% If no figure exists, one will be created with the title found in the edit
% box.
%
% Suggested exercise:  Alter the code so that an xlabel and ylabel
% also are added.  This could be done by making 2 more edits, and having
% the pushbutton use the information from all 3 edits to do the job.
%
%
% Author:  Matt Fig
% Date:  7/15/2009

S.fh = figure('units','pixels',...
              'position',[500 500 350 50],...
              'menubar','none',...
              'numbertitle','off',...
              'name','GUI_20',...
              'resize','off');
S.ed = uicontrol('style','edit',...
                 'units','pixels',...
                 'position',[10 10 220 30],...
                 'fontsize',14,...
                 'string','Enter Title');
S.pb = uicontrol('style','push',...
                 'units','pixels',...
                 'position',[240 10 100 30],...
                 'fonts',14,...
                 'str','Insert Title',...
                 'callback',{@pb_call,S});
           
function [] = pb_call(varargin)
% Callback for the button labeled PUSH_1.
S = varargin{3}; % Get the structure.
CH = get(0,'children'); % Get all figures.
if numel(CH)~=1  % If only 1, that is this GUI!
   AX = get(CH(2),'children');  % Second in list was cf before callback.
   if ~isempty(AX)
       T = get(AX,'title');  % Titles are objects!
       set(T,'string',get(S.ed,'string')) % Set the title.
   end
else
    % There are other options here.  The GUI could popup a message box
    % saying, "No axes to title!" or something similar.
    figure  % Create a figure.
    title(get(S.ed,'string'))  % This will create an axes too.
end
    








